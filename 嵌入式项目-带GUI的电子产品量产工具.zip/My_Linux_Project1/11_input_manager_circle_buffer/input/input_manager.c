#include <pthread.h>
#include <stdio.h>
#include <unistd.h>
#include <semaphore.h>
#include <string.h>

//定义一些锁：对于输入系统而言，会有触摸屏的线程访问环形缓冲区，或者网络输入的线程访问环形缓冲区
//或者上层APP读取数据时，也会有线程来访问环形缓冲区，所以访问环形缓冲区的时候，应该加上一个锁
static pthread_mutex_t g_tMutex  = PTHREAD_MUTEX_INITIALIZER;
static pthread_cond_t  g_tConVar = PTHREAD_COND_INITIALIZER;


//start of 实现环形buffer
//首先要有读写指针
static int g_iRead 	= 0;
static int g_iWrite = 0;
//定义一个宏用来描述长度
#define BUFFER_LEN 20
static InputEvent g_atInputEvents[BUFFER_LEN];//构建一个存放的项为InputEvent结构体类型的数组

static int isInputBufferFull(void)
{
	return (g_iRead == ((g_iWrite + 1) % BUFFER_LEN));//如果读位置和下一个写位置相等，则为满
}

static int isInputBufferEmpty(void)
{
	return (g_iRead == g_iWrite);//如果读写位置相等的话，那就是空的
}

//存放数据
static void PutInputEventToBuffer(PInputEvent ptInputEvent)
{
	//如果环形缓冲区满了的话，就不放，啥都不做
	if (!isInputBufferFull())
	{
		g_atInputEvents[g_iWrite] = ptInputEvent;
		g_iWrite = (g_iWrite + 1) % BUFFER_LEN;
	}
}
//获得数据
static int GetInputEventFromBuffer(PInputEvent ptInputEvent)
{
	//如果环形缓冲区不空
	if (!isInputBufferEmpty())
	{
		ptInputEvent = g_atInputEvents[g_iRead];
		g_iRead = (g_iRead + 1) % BUFFER_LEN;
		return 1;
	}
	return 0;
}


//end of 实现环形buffer


static PInputDevice g_InputDevs = NULL;//先创建一个链表头，一开始为空
//当链表里面有两个设备以后，就要把里面的每个设备取出来，并调用里面的DeviceInit()来初始化硬件
//并且为每一个设备创建一个线程
//然后再提供一个注册函数
void RegisterInputDevice(PInputDevice ptInputDev)//用于下一层结构体的注册进入这个链表，以便于被使用
{
	ptInputDev->ptNext = g_InputDevs;//这个结构体的下一个指向链表头
	g_InputDevs = ptInputDev;//链表头就是这个结构体
}


//向上提供一个InputInit()函数，对这些设备进行注册
void InputInit(void)
{
	//register touchscreen
	extern void TouchscreenRegister(void);//使用外部函数
	TouchscreenRegister();
	
	//register netinput
	extern void NetinputRegister(void );
	TouchscreenRegister();

	
}

//我们要实现下面这个函数，它是核心之一
static void *input_recv_thread_func (void *data)
{
	//首先要从data里面得到传进来的结构体ptTmp
	PInputDevice ptInputDev = (PInputDevice)data;
	//要在线程的while里面不断的读数据,得到的结果放在下面的结构体里面
	//即读数据、保存数据和唤醒其它线程
	InputEvent tEvent;
	int ret;
	while (1)
	{
		//如果没有数据的话，就会进入休眠；有数据的话，就会返回
		//所以要判断下返回值，
		ret = ptInputDev->GetInputEvent(&tEvent);得到的数据放入结构体tEvent里面
		if(!ret)//如果成功，则做下面的事情
		{
			//保存数据,得到的数据要保存在一个buf里面，这个buf要足够大，否则数据就会丢失
			//因为保存数据到环形缓冲区，所以要实现获得环形缓冲区的锁
			pthread_mutex_lock(&g_tMutex);
			PutInputEventToBuffer(&tEvent);
			
			//可能有别的线程在等待数据，所以要唤醒等待数据的线程
			pthread_cond_signal(&g_tConVar);
			pthread_mutex_unlock(&g_tMutex);
		}

	}

	return NULL;
}

//调用下面的函数，就可以创建线程
void InputDeviceInit()
{
	//for each inputdevice,init,pthread_create
//对于链表，我们要把里面的每一项都取出来，
	PInputDevice ptTmp = g_InputDevs;//定义一个变量，指向链表头
	while(ptTmp)//如果存在的话，就执行某些操作
	{
		int ret;
		//初始化设备 init device
		ret = ptTmp->DeviceInit();//直接调用改设备的初始化函数，注意返回值

		//创建线程 pthread create
		if(!ret)//初始化成功的话，执行下面的操作
		{
			//调用pthread_create()
//参照E:\QRS\QRS-Git\01_all_series_quickstart\04_嵌入式Linux应用开发基础知识\source\13_thread\02_视频配套源码
//里面的第五个文件
			pthread_t tid;
			ret = pthread_create(&tid, NULL, input_recv_thread_func, ptTmp);
		//对于上面的第三个参数（函数），对于不同的设备使用同一个函数的情况，那么我们需要使用某个参数来分辨
		//所以第四个参数改为传入结构体，那么以后就可以从input_recv_thread_func(void *data)里面的data里面得到这个ptTmp结构体

		}

		//指向下一个节点 
		ptTmp = ptTmp->ptNext;
	}
	

}

//最上层代码通过这个函数就能得到触摸屏的数据，或者网络输入的数据
int GetInputEvent(PT_inputEvent ptInputEvent)
{
	InputEvent tevent;
	int ret;
//无数据，则休眠
	//如果想要获得环形缓冲区，得先获得这个锁
	pthread_mutex_lock(&g_tMutex);
	//上锁之后，直接调用下面的函数，
	if(GetInputEventFromBuffer(&tevent))//将数据放在这里面,如果成功获得数据的话，就释放锁
	{
		pthread_mutex_unlock(&g_tMutex);
		return 0;
	}
	else
	{
		//如果失败的话，就休眠等待，通过调用下面的函数来休眠；
		//如果从下面的函数返回，说明被其它设备的线程唤醒了，唤醒之后，就可以再次读取数据
		pthread_cond_wait(&g_tConVar, &g_tMutex);//唤醒之后，这个锁又再次获得了
		if(GetInputEventFromBuffer(&tevent))
		{
			ret = 0;//如果读到数据，表示成功
		}
		else
		{
			ret = -1;//表示失败
		}
		pthread_mutex_unlock(&g_tMutex);//在返回之前，要释放这个锁
	}
	return ret;
//否则的话，就返回数据

}







