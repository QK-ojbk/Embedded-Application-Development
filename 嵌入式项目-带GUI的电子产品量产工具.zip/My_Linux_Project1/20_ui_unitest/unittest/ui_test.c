//将以前写的show_ascii.c文件全部粘贴到这个文件中
#include <sys/mman.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <linux/fb.h>
#include <fcntl.h>
#include <stdio.h>
#include <string.h>
#include <sys/ioctl.h>
#include <stdlib.h>

#include "disp_manager.h"
#include "font_manager.h"
#include "ui.h"


int main(int argc, char **argv)
{
	PDispBuff ptBuffer;
	int error;
	Button tButton;//按钮
	Region tRegion;//设置一个区域

	if(argc != 2)
	{
		printf("Usage: %s <font_size>\n",argv[0]);
		return -1;
	}
	//1.先初始化显示系统
	//以前的main函数里面刚开始是打开节点，现在都不需要了
	//对硬件的操作也都封装好了，
	//从头文件中调用下面的函数
	DisplayInit();//该函数回去调用FramebufferInit()，然后去注册结构体g_tFramebufferOpr

	//选择默认的显示设备
	SelectDefaultDisplay("fb");

	//初始化默认的设备
	InitDefaultDisplay();
	//2.再初始化字体系统
	//选择好默认的设备之后，就去获得那个buffer
	ptBuffer = GetDisplayBuffer();
	
	//字体初始化
	FontsRegister();

	//设置文件字库和初始化
	error = SelectAndInitFont("freetype",argv[1]);//参数1是选择某一个字库操作，参数2是字体文件，来源于输入参数
	if(error)
	{
		printf("SelectAndInitFont err\n");//font_file保存在argv[1]里面
		return -1;
	}

	//3.初始化UI系统
	//首先初始化按钮：初始化一个名为test的按钮
	//设定这个按钮显示在哪个区域；同时设定OnDraw和OnPressed函数为默认
	tRegion.iLeftUpX 	= 200;
	tRegion.iLeftUpY 	= 200;
	tRegion.iWidth 		= 300;
	tRegion.iHeigh		= 100;
	InitButton(&tButton, "test", &tRegion, NULL, NULL);
	tButton.OnDraw(&tButton, ptBuffer);
	while(1)
	{
		tButton.OnPressed(&tButton, ptBuffer,NULL);
		sleep(2);//点击一次就休眠两秒钟
	}
	
	return 0;	
}

//从上面的main函数来看，根本就不涉及到硬件的操作，都被封装好了




