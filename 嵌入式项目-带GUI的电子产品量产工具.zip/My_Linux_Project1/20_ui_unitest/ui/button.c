#include "ui.h"

//默认的绘制按钮的函数：想要绘制默认是红色底，黑色字；那么我们需要实现一个函数，在选定区域内清成某种函数
//那么就需要在disp_manager.c里面实现另一个函数
static int DefaultOnDraw(struct Button *ptButton, PDispBuff ptDispBuff)
{
	//绘制底色：将这块区域绘制成某一个颜色，这里默认为红色；在disp_manager.c里面实现下面的函数
	DrawRegion(&ptButton->tRegion,BUTTON_DEFAULT_COLOR);
	//居中写文字
	//ptButton->name为要写的“按钮的名称”,地址为ptButton->tRegion，颜色为黑色;该函数在disp_manager.c里面实现
	DrawTextInRegionCentral(ptButton->name, &ptButton->tRegion, BUTTON_TEXT_COLOR);
	//刷新 flush to lcd/web
	FlushDisplayRegion(&ptButton->tRegion, ptDispBuff);//将区域参数1刷新到参数2
	return 0;
}

static int DefaultOnPressed(struct Button *ptButton, PDispBuff ptDispBuff, PInputEvent ptInputEvent)
{
	unsigned int dwColor = BUTTON_DEFAULT_COLOR;
	//希望点击一次后，这块区域由默认的红色变为绿色，再点击依次，将由绿色变为红色
	//所以需要再原来构建的Button结构体里面构建一个标志位
	//每一次点击，状态都要翻转下
	ptButton->status = !ptButton->status;
	if(ptButton->status)//如果状态是1的话，颜色就变为绿色
		dwColor = BUTTON_PRESSED_COLOR;
	//然后调用同样的函数来修改颜色
	DrawRegion(&ptButton->tRegion,dwColor);
	DrawTextInRegionCentral(ptButton->name, &ptButton->tRegion, BUTTON_TEXT_COLOR);
	FlushDisplayRegion(&ptButton->tRegion, ptDispBuff);//将区域参数1刷新到参数2
	return 0;
}


//初始化按键，初始化某一个按键
//形参1是初始化某一个按键，形参2就是传入一个名字，形参3是一个范围,形参4、5提供一个指针函数
//目的是初始化按钮button,并分别设置成后面的东西
void InitButton(PButton ptButton, char *name, PRegion ptRegion, ONDRAW_FUNC OnDraw, ONPRESSED_FUNC OnPressed)
{
	ptButton->status 	= 0;//点击的初始状态为0
	ptButton->name 		= name;
	ptButton->tRegion 	= *ptRegion;
	ptButton->OnDraw 	= OnDraw ? OnDraw : DefaultOnDraw;//OnDraw是否存在的话，存在的话就等于OnDraw，不存在的话等于默认的DefaultOnDraw
	ptButton->OnPressed = OnPressed ? OnPressed : DefaultOnPressed;
}




























