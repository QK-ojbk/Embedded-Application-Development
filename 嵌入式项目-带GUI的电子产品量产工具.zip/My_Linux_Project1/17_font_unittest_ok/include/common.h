#ifndef __COMMON_H
#define __COMMON_H
//自己定义一个NULL
#ifndef NULL
#define NULL (void *)0
#endif

typedef struct Region {
	int iLeftUpX;
	int iLeftUpY;
	int iWidth;//宽度
	int iHeigh;//高度
}Region,*PRegion;//我们用左上角的x,y坐标，和右下角的x,y坐标来表示一个区域;结构体以后用Region表示，指针以后用PRegion表示



#endif

