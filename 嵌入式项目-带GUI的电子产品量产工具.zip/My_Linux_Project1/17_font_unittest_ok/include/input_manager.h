//对于头文件，为了防止重复包含，应该定义一些宏
#ifndef __INPUT_MANAGER_H
#define __INPUT_MANAGER_H
//定义输入类型
#define INPUT_TYPE_TOUCH 1
#define INPUT_TYPE_NET 2

#include <sys/time.h>
#include "common.h"



//对数据本身能够抽象出一个结构体
typedef struct InputEvent {
//仿照tslib添加一个事件值
	struct timeval tTime;
	int iType;
	int ix;
	int iy;
	int iPressure;//以上用于触摸屏事件
	char str[1024];//对于网络事件
}InputEvent,*PInputEvent;
//参考E:\QRS\QRS-Git\01_all_series_quickstart\04_嵌入式Linux应用开发基础知识\source\11_input\02_tslib里面的文件
//看别人是怎么得到触摸屏的数据的

//下面要抽象出第二个结构体，来表示输入设备
//对于输入设备而言，需要得到输入数据
typedef struct InputDevice {
	char *name;
	//提供一个函数指针，返回值表示是否成功，如果成功的化，数据保存在参数里面
	int (*GetInputEvent)(PInputEvent ptInputEvent);
	//需要提供一些初始化函数来打开设备节点
	int (*DeviceInit)(void);
	int (*DeviceExit)(void);
	struct InputDevice *ptNext;
}InputDevice,*PInputDevice;

void RegisterInputDevice(PInputDevice ptInputDev);
void InputDeviceInit();
int GetInputEvent(PInputEvent ptInputEvent);
void InputInit(void);



#endif





