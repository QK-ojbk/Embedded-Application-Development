
#include <string.h>
#include "font_manager.h"

static PFontOpr g_ptDefaultFontOpr = NULL;
static PFontOpr g_ptFonts = NULL;
//下面的注册函数，注册的节点放入一个链表中
void RegisterFont(PFontOpr ptFontOpr)
{
	ptFontOpr->ptNext	= g_ptFonts;
	g_ptFonts			= ptFontOpr;
}

void FontsRegister(void)
{
	extern void FreetypeRegister(void);
	FreetypeRegister();//底层的freetype.c应该提供一个注册函数
}


//假设有多种字库，那么需要提供一个选择函数，形参为一个字体文件
int SelectAndInitFont(char *aFontOprName,char *aFontFileName)
{
	//要从上面的链表里面，选择一个字库
	PFontOpr ptTmp = g_ptFonts;
	while(ptTmp)
	{
		if(strcmp(ptTmp->name, aFontOprName) == 0)//如果节点里面的名字等于传进来的名字
			break;
		ptTmp = ptTmp->ptNext;
	}
	if(!ptTmp)//如果不存在
		return -1;
	g_ptDefaultFontOpr = ptTmp;//找到这个节点后，把它先保存在一个全局变量中
	return ptTmp->FontInit(aFontFileName);//如果存在，则调用它的初始化函数,形参为一个字体文件
}
//下面两个函数直接照抄先前实现的freetype.c文件里面的对应的两个函数
int SetFontSize(int iFontSize)
{
	//直接调用之前找到的默认的节点结构体里面的设置字体大小函数
	return g_ptDefaultFontOpr->SetFontSize(iFontSize);
}

int GetFontBitMap(unsigned int dwCode,PFontBitMap ptFontBitMap)
{
	return g_ptDefaultFontOpr->GetFontBitMap(dwCode, ptFontBitMap);
}








