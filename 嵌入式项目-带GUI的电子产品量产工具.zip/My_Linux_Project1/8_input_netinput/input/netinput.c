//可以参考
//E:\QRS\QRS-Git\01_all_series_quickstart\04_嵌入式Linux应用开发基础知识\source\12_socket\udp2
//参考里面的client.c和server.c
//这部分程序在网络程序中将作为server端，其它程序将作为client向它发送程序
//所以在该部分代码里面构造server
#include <input_manager.h>
#include <sys/types.h>          /* See NOTES */
#include <sys/socket.h>
#include <string.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <stdio.h>
#include <signal.h>
#include <string.h>

/* socket
 * bind
 * sendto/recvfrom
 */

#define SERVER_PORT 8888
static int g_iSocketServer;


#ifndef NULL
#define NULL (void *)0
#endif

//提供一个函数指针，返回值表示是否成功，如果成功的化，数据保存在参数里面
static int NetinputGetInputEvent(PInputEvent ptInputEvent)
{
	struct sockaddr_in tSocketClientAddr;
	int iRecvLen;
	unsigned char ucRecvBuf[1000];
	
	int iAddrLen = sizeof(struct sockaddr);
	
	iRecvLen = recvfrom(g_iSocketServer, ucRecvBuf, 999, 0, (struct sockaddr *)&tSocketClientAddr, &iAddrLen);
	if (iRecvLen > 0)
	{
		ucRecvBuf[iRecvLen] = '\0';
		//printf("Get Msg From %s : %s\n", inet_ntoa(tSocketClientAddr.sin_addr), ucRecvBuf);
		ptInputEvent->iType		= INPUT_TYPE_NET;//是网络输入事件
		gettimeofday(&ptInputEvent->tTime,NULL);
		strncpy(ptInputEvent->str,ucRecvBuf);
		ptInputEvent->str[999]='\0';
		return 0;
	}
	else
		return 0;
}

//需要提供一些初始化函数来打开设备节点
static int NetinputDeviceInit(void)
{
	//将参考文件里面的main函数里面的前半部分拷贝过来，
	struct sockaddr_in tSocketServerAddr;
	int iRet;
	int iAddrLen;
	
	int iClientNum = -1;
	
	g_iSocketServer = socket(AF_INET, SOCK_DGRAM, 0);
	if (-1 == g_iSocketServer)
	{
		printf("socket error!\n");
		return -1;
	}

	tSocketServerAddr.sin_family      = AF_INET;
	tSocketServerAddr.sin_port        = htons(SERVER_PORT);  /* host to net, short */
 	tSocketServerAddr.sin_addr.s_addr = INADDR_ANY;
	memset(tSocketServerAddr.sin_zero, 0, 8);
	
	iRet = bind(g_iSocketServer, (const struct sockaddr *)&tSocketServerAddr, sizeof(struct sockaddr));
	if (-1 == iRet)
	{
		printf("bind error!\n");
		return -1;
	}

	return 0;
}

static int NetinputDeviceExit(void)
{
	close(g_iSocketServer);
	return 0;
}

struct InputDevice *ptNext;




static InputDevice g_tNetinputDev = {
	.name			= "Netinput",
	.GetInputEvent	= NetinputGetInputEvent,
	.DeviceInit		= NetinputDeviceInit,
	.DeviceExit		= NetinputDeviceExit,
};

#if 0
int main(int argc, char **argv)
{
	InputEvent event;
	int ret;
	g_tNetinputDev.DeviceInit();
	while(1)
	{
		ret = g_tNetinputDev.GetInputEvent(&event);
		if(ret)
		{
			printf("GetInputEvent err!\n");
			return -1;
		}
		else
		{
			printf("Type 	  : %d\n", event.iType);
			printf("ix 	  : %d\n", event.ix);
			printf("iy 	  : %d\n", event.iy);
			printf("iPressure : %d\n", event.iPressure);
		}
	}
	return 0;
}
#endif

