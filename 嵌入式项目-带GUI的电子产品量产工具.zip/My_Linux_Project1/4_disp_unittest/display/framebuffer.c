#include <sys/mman.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <linux/fb.h>
#include <fcntl.h>
#include <stdio.h>
#include <string.h>
#include <sys/ioctl.h>

//包含刚才自己构建的头文件
#include "disp_manager.h"
//下面这些参数源自参考文件
static int fd_fb;
static struct fb_var_screeninfo var;	/* Current var */
static int screen_size;
static unsigned char *fb_base;
static unsigned int line_width;
static unsigned int pixel_width;

static int FbDeviceInit(void)//仿照以前的代码写初始化
{
		fd_fb = open("/dev/fb0", O_RDWR);
		if (fd_fb < 0)
		{
			printf("can't open /dev/fb0\n");
			return -1;
		}
		if (ioctl(fd_fb, FBIOGET_VSCREENINFO, &var))
		{
			printf("can't get var\n");
			return -1;
		}
	
		line_width	= var.xres * var.bits_per_pixel / 8;
		pixel_width = var.bits_per_pixel / 8;
		screen_size = var.xres * var.yres * var.bits_per_pixel / 8;
		fb_base = (unsigned char *)mmap(NULL , screen_size, PROT_READ | PROT_WRITE, MAP_SHARED, fd_fb, 0);
		if (fb_base == (unsigned char *)-1)
		{
			printf("can't mmap\n");
			return -1;
		}

	return 0;//最后成功的化，返回0
}

int FbDeviceExit(void)
{
	//查看虚拟机得到mmap的反函数为munmap以及使用格式
	munmap(fb_base,screen_size);//地址，长度
	close(fd_fb);//关闭这个文件句柄
	return 0;
}


//下面的函数声明为static,以后要去使用这个函数，必须要通过结构体g_tFramebufferOpr来使用
//以后上层代码调用这个GetBuffer函数的时候,除了得到这个buf的显存的地址之外，还可以得到分辨率和每个像素使用多少位来表示
//下面这个函数可以返回lcd本身使用的那块framebuffer（那块显存），也可以通过malloc给它返回一块与lcd/framebuffer无关的内存；
//1.可以返回LCD的framebuffer，以后上层APP可以直接操作LCD，那么这时候，对于下面的FlushRegion函数而言，可以为空函数，即不用FlushRegion()函数
//2.也可以通过malloc返回一块无关的buffer,上传APP并操作这个buf之后，那么必须通过FlushRegion()函数将其数据刷到LCD上面去
//下面为了简单，则让函数返回LCD的framebuffer，那么在下面的函数里面，首先要获得LCD的fremabuffer，那显然，对于结构体g_tFramebufferOpr里面还需要一些初始化函数
static int FbGetBuffer(PDispBuff ptDisBuff)//提供一个GetBuffer()函数
{
	//由上面初始化后，得到一些数据，给该函数使用
	ptDisBuff->iXres = var.xres;//x方向的分辨率
	ptDisBuff->iYres = var.yres;//y方向的分辨率
	ptDisBuff->iBpp = var.bits_per_pixel;
	ptDisBuff->buff = (char *)fb_base;
	return 0;//返回0表示成功，即把显存的地址返回给上层去，那么以后就不需要FbFlushRegion

}
//刷新某个区域，这个区域用结构体来表示，前面定义；要刷新的区域就是Region,数据在buffer里面
static int FbFlushRegion(PRegion ptRegion, PDispBuff ptDispBuff)
{
	return 0;
}
//在前面将应用基础时，我们曾经使用framebuffer,在lcd上面显示了各种图片，可以参考那些代码
//参考E:\QRS\QRS-Git\01_all_series_quickstart\04_嵌入式Linux应用开发基础知识\source\07_framebuffer里面的show_pixel.c
//复制使用其头文件

//构造一个类似file_operations的结构体
//构造这样一个结构体，里面有各种函数，对于上层代码而言，可以使用这个结构体里面的函数，来初始化LCD和得到framebuffer
//我们在这个framebuffer里面构造好图像和文字之后，再把它Flush刷到LCD上面去
static DispOpr g_tFramebufferOpr = {
	.name 			= "fb",
	.DeviceInit		=FbDeviceInit,//先构建初始化函数，同时，有初始化就应该有退出
	.DeviceExit		=FbDeviceExit,
	.GetBuffer		=FbGetBuffer,//需要写出这两个函数
	.FlushRegion	=FbFlushRegion,

};

void FramebufferInit(void)
{
	RegisterDisplay(&g_tFramebufferOpr);//注册这个结构体进入链表中，即把这层里面自己构造的结构体注册到上层的链表中去

}





