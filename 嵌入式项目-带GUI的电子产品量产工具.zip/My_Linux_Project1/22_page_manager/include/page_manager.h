//对于头文件，为了防止重复包含，应该定义一些宏
#ifndef __PAGE_MANAGER_H
#define __PAGE_MANAGER_H

//对于每个页面而言，都会实现下面这个结构体
typedef struct PageAction {
	char *name;
	void (*Run)(void *pParams);//用viod*指向任意的一个参数
	struct PageAction *ptNext;
}PageAction,*PPageAction;
void PageRegister(PPageAction ptPageAction);
PPageAction Page(char *name);
void PagesRegister(void);


#endif





