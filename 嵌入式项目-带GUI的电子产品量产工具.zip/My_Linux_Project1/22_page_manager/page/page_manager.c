
#include "page_manager.h"
#include "common.h"
#include <string.h>

static PPageAction g_ptPages = NULL;//链表头

//将某个页面注册到链表中去,即注册一个页面
void PageRegister(PPageAction ptPageAction)
{
	ptPageAction->ptNext = g_ptPages ;//将每个页面实现的PageAction结构体，注册到链表中去
	g_ptPages 			 = ptPageAction;
}
//希望这个函数返回一个指针，即获得某一个页面
PPageAction Page(char *name)
{
	//在上面的链表中找到同名项
	ptPageAction ptTmp = g_ptPages;
	while(ptTmp)//如果链表存在的话，就去比较下
	{
		if(strcmp(name,ptTmp->name) == 0)
			return ptTmp;//如果找到的话，就返回这个指针
		//没有找到的话，就指向链表的下一个节点
		ptTmp = ptTmp->ptNext;
	}
	return NULL;//没有找到的话，就返回空指针
}


//可以用于注册多个页面，即注册多个页面
void PagesRegister(void)
{
	//实现的MainPageregister会去调用PageRegister(PPageAction ptPageAction)
	//将其自己放入链表
	//MainPageregister();

}















