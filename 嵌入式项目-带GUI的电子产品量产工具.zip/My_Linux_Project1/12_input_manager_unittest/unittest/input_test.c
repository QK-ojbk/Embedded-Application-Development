//将以前写的show_ascii.c文件全部粘贴到这个文件中
#include <sys/mman.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <linux/fb.h>
#include <fcntl.h>
#include <stdio.h>
#include <string.h>
#include <sys/ioctl.h>
#include "input_manager.h"

static InputDevice g_tNetinputDev;

int main(int argc, char **argv)
{
	InputInit();
	InputDeviceInit();
	int ret;
	InputEvent event;//将读到的输入事件，存在这个结构体里面
//使用一个while循环来不断你的读取数据
	while(1)
	{
		ret = g_tNetinputDev.GetInputEvent(&event);
		if(ret)
		{
			printf("GetInputEvent err!\n");
			return -1;
		}
		else
		{
			if (event.iType == INPUT_TYPE_TOUCH)//如果是触摸屏输入事件的话
			{
			printf("Type	  	: %d\n", event.iType);
			printf("iX 	  		: %d\n", event.ix);
			printf("iY 	 		: %d\n", event.iy);
			printf("iPressure 	: %d\n", event.iPressure);
			}
			else if (event.iType == INPUT_TYPE_NET)//如果是网络输入事件的话
			{
				printf("Type 	  : %d\n", event.iType);
				printf("str 	  : %s\n", event.str);
			}
		}
	}
//从上面的main函数来看，根本就不涉及到硬件的操作，都被封装好了
}



