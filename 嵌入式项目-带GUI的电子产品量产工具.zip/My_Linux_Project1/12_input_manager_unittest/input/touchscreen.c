
#include "input_manager.h"
#include <tslib.h>
#include <stdio.h>

static struct tsdev *g_ts;
#ifndef NULL
#define NULL (void *)0
#endif

//提供一个函数指针，返回值表示是否成功，如果成功的化，数据保存在参数里面
static int TouchscreenGetInputEvent(PInputEvent ptInputEvent)
{
	//要将读到的数据转换为PInputEvent结构体
	struct ts_sample samp;
	int ret;
	ret = ts_read(g_ts, &samp, 1);//读这个g_ts设备
	if (ret != 1)
		return -1;
	ptInputEvent->iType		= INPUT_TYPE_TOUCH;//是触摸屏事件
	ptInputEvent->ix		= samp.x;//ix值等于ts_sample里面的某一个成员
	ptInputEvent->iy		= samp.y;
	ptInputEvent->iPressure	= samp.pressure;
	ptInputEvent->tTime		= samp.tv;
	return 0;
}

//需要提供一些初始化函数来打开设备节点
static int TouchscreenDeviceInit(void)
{
	//对于设备的初始化，直接调用ts_setup即可
	g_ts = ts_setup(NULL, 0);
	if (!g_ts)
	{
		printf("ts_setup err\n");
		return -1;
	}
	return 0;
}

static int TouchscreenDeviceExit(void)
{
	ts_close(g_ts);//关闭这个设备
	return 0;
}

struct InputDevice *ptNext;



//对于这个结构体里面的函数的构建，可以参考
//E:\QRS\QRS-Git\01_all_series_quickstart\04_嵌入式Linux应用开发基础知识\source\11_input\02_tslib
//里面的mt_cal_distance.c文件
static InputDevice g_tTouchscreenDev = {
	.name			= "touchscreen",
	.GetInputEvent	= TouchscreenGetInputEvent,
	.DeviceInit		= TouchscreenDeviceInit,
	.DeviceExit		= TouchscreenDeviceExit,
};


//为了将构造的结构体能够注册到上一层管理系统里面去，构造下面的函数
//同时，上一层代码要提供一个将结构体注册到链表里面的函数
//最终下面的这个函数被上一侧管理文件里面的输入初始化函数调用
void TouchscreenRegister(void)
{
	RegisterInputDevice(&g_tTouchscreenDev);

}


