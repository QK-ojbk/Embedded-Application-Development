
#ifndef __UI_H
#define __UI_H
#include "common.h"
#include "disp_manager.h"
#include "input_manager.h"
typedef struct Button {
	char *name;//按键对应的名字
	Region tRegion;
	//绘制出来：形参1是绘制这个按钮本身，形参2是在哪里绘制
	int (*OnDraw)(struct Button *ptButton, PDispBuff ptDispBuff);
	//按钮绘制出来，那么人点击要有反应
	int (*OnPressed)(struct Button *ptButton, PDispBuff ptDispBuff, PInputEvent ptInputEvent);
	
};


#endif

