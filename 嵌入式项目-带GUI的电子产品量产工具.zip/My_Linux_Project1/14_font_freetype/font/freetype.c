//参考应用变成里面的freetype代码库
//E:\QRS\QRS-Git\01_all_series_quickstart\04_嵌入式Linux应用开发基础知识
//\source\10_freetype\04_show_line
#include <sys/mman.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <linux/fb.h>
#include <fcntl.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <wchar.h>
#include <sys/ioctl.h>

#include <ft2build.h>
#include FT_FREETYPE_H
#include FT_GLYPH_H


#include "font_manager.h"

static FT_Face g_tface;
static int g_iDefaultFontSize = 12;
static int FreeTypeFontInit(char *aFineName)
{
	FT_Library	library;
	int error;

	error = FT_Init_FreeType( &library );			   /* initialize library */
	if(error)
	{
		printf("FT_Init_FreeType err\n");
		return -1;
	}
	//下面函数的第二个参数是文件名，即字库的文件名
	error = FT_New_Face(library, aFineName, 0, &g_tface ); /* create face object */
	if(error)
	{
		printf("FT_New_Face err\n");
		return -1;
	}

	FT_Set_Pixel_Sizes(g_tface, g_iDefaultFontSize, 0);//这里设置一个默认的字体大小，以防后面忘记设计字体了
	
	return 0;
}
static int FreeTypeSetFontSize(int iFontSize)
{
	FT_Set_Pixel_Sizes(g_tface, iFontSize, 0);//设置为任何字体的大小
	return 0;
}
static int FreeTypeGetFontBitMap(unsigned int dwCode,PFontBitMap ptFontBitMap)
{
	int error;
	//先得到位图，在计算坐标点
	//首先对于一个字符，如何得到它的位图呢
	FT_Vector pen;//
	FT_Glyph  glyph;
	FT_GlyphSlot slot = g_tface->glyph;
	
	//起笔点确定为基点
	pen.x = ptFontBitMap->iCurOriginX * 64; /* 单位: 1/64像素 */
	pen.y = ptFontBitMap->iCurOriginY * 64; /* 单位: 1/64像素 */
	
	//将起笔点pen告诉freetype
	/* 转换：transformation */
	FT_Set_Transform(g_tface, 0, &pen);

	//加载位图
	/* 加载位图: load glyph image into the slot (erase previous one) */
	error = FT_Load_Char(g_tface, wstr[i], FT_LOAD_RENDER);
	if (error)
	{
		printf("FT_Load_Char error\n");
		return -1;
	}

	//先将点阵记录下来
	ptFontBitMap->pucBuffer		= slot->bitmap.buffer;
	ptFontBitMap->iLeftUpX		= slot->bitmap_left;
	//坐标系不一样，后面再改,在在freetype里面，用到的是笛卡尔坐标，即Y坐标向上
	//要将其转换为lcd坐标,坐标中Y轴是向下的
	ptFontBitMap->iLeftUpY		= ptFontBitMap->iCurOriginY * 2 -slot->bitmap_top;//坐标系不一样，后面再改
	ptFontBitMap->iWidth		= slot->bitmap.width;
	ptFontBitMap->iRows			= slot->bitmap.rows;
	ptFontBitMap->iNextOriginX	= ptFontBitMap->iCurOriginX + slot->advance.x/64;//单位不一样，要转换下
	ptFontBitMap->iNextOriginY	= ptFontBitMap->iCurOriginY;//字符在同一个水平线上，所以Y轴不变
	return 0;
}


static FontOpr g_tFreetypeOpr = {
	//一下均为函数指针
	.name			= "freetype";//以后根据这个名字来选择，找到这个结构体
	.FontInit		= FreeTypeFontInit;
	.SetFontSize	= FreeTypeSetFontSize;
	.GetFontBitMap	= FreeTypeGetFontBitMap;
}













