
#ifndef __CONFIG_H
#define __CONFIG_H
#include "common.h"

#define ITEMCFG_MAX_NUM 30

//配置文件是啥，得定义一个宏，提供一个默认的配置文件
#define CFG_FILE "/etc/test_gui/gui.conf"


//定义结构体，用来描述配置文件里面的每一行
typedef struct ItemCfg {
	int index;
	char name[100];//名字用一个数组来保存进来
	int bCanBeTouched;
	char command[100];
}ItemCfg, *PItemCfg;




//定义几个接口函数，给别人使用

//确定配置文件有多少行，有多少行，就有多少个按钮;函数返回值为数量
int GetItemCfgCount(void);

//想要获得某个ItemCfg，那么构造的函数就返回一个指针;传入index，返回某个配置项
PItemCfg GetItemCfgByIndex(int index);
//或者是传入名字，返回某个配置项
PItemCfg GetItemCfgByName(char *name);

int ParseConfigFile(char *strFilename);






#endif

