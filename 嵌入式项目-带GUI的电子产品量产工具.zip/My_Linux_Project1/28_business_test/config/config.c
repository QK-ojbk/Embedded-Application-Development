
#include "config.h"
#include <string.h>
#include <stdio.h>
//要实现头文件里面声明的函数，但在此之前，要先解析配置文件
//传入配置文件的名字;解析配置文件时，解析每一项，得到一个ItemCfg结构体
//得到的结构体保存在一个链表中，为了让程序更简单，用数组来实现
static ItemCfg g_tItemCfgs[ITEMCFG_MAX_NUM];//用于存放配置文件里面每一行的数据
static int g_iItemCfgCount = 0;

int ParseConfigFile(void)//使用默认的配置文件路径，不需要传入文件名
{
	FILE *fp;//先设置一个文件指针
	char buf[100];
	char *p = buf;
	
	/*1.打开配置文件*/
	fp = fopen(CFG_FILE, "r");
	if(!fp)
	{
		printf("can not open cfg file %s\n", CFG_FILE);
		return -1;
	}

	while(fgets(buf, 100, fp))//每个循环用fgets读入一行，最大数量为100
	{
		/*2.1 处理每一行，即读出每一行*/
		buf[99] = '\0';
		
		/*2.2 吃掉开头的空格或这tab键*/
		//或者前面有空格，所以需要将空格和tab键吃掉
		p = buf;
		while(*p == ' ' || *p == '\t')
			p++;

		/*2.3 忽略注释*/
		//配置文件里面，有些注释是通过“#”；如果发现某一行开头是#，则这行忽略掉，直接下一行
		if(*p == '#')
			continue;

		/*2.4 处理某一行*/
		//name can_be_touch command--->%s %d %s
		g_tItemCfgs[g_iItemCfgCount].command[0] = '\0';//以后根据第0项就能判断下这一项有没有command
		//上面，这一项不等于0的话，就表明它从配置文件里面得到了它的值
		g_tItemCfgs[g_iItemCfgCount].index = g_iItemCfgCount;
		sscanf(p, "%s %d %s", g_tItemCfgs[g_iItemCfgCount].name,&g_tItemCfgs[g_iItemCfgCount].bCanBeTouched,\
							   g_tItemCfgs[g_iItemCfgCount].command);
		g_iItemCfgCount++;
		
	}
	return 0;
}

//下面三个函数实现的前提是：解析了配置文件
int GetItemCfgCount(void)
{
	return g_iItemCfgCount;
}

PItemCfg GetItemCfgByIndex(int index)
{
	if(index < g_iItemCfgCount)
		return &g_tItemCfgs[index];
	else
		return NULL;
}

PItemCfg GetItemCfgByName(char *name)
{
	int i;
	for(i = 0; i < g_iItemCfgCount; i++)
	{
		if(strcmp(name,g_tItemCfgs[i].name) == 0)
			return &g_tItemCfgs[i];
	}
	return NULL;//如果没找到，返回空指针
}










