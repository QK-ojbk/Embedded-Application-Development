
#include "page_manager.h"
#include "config.h"
#include <math.h>
#include <stdio.h>
#include "ui.h"
#include <string.h>
#include "common.h"

#define X_GAP 5
#define Y_GAP 5

static int g_tButtonCnt;//按钮个数
static Button g_tButtons[ITEMCFG_MAX_NUM];//最多有这么多按钮

static int MainPageOnPressed(struct Button *ptButton, PDispBuff ptDispBuff, PInputEvent ptInputEvent)
{
	unsigned int dwColor = BUTTON_DEFAULT_COLOR;
	char name[100];
	char status[100];
	char *strButton;//按钮自己的名字
	strButton = ptButton->name;
	/* 1. 对于触摸屏事件，要判断下是否是触摸屏事件*/
	if(ptInputEvent->iType == INPUT_TYPE_TOUCH)
	{
		//分辨能否被点击
		if(GetItemCfgByName(ptButton->name)->bCanBeTouched == 0)
		//修改颜色
		//希望点击一次后，这块区域由默认的红色变为绿色，再点击依次，将由绿色变为红色
		//所以需要再原来构建的Button结构体里面构建一个标志位
		//每一次点击，状态都要翻转下
		ptButton->status = !ptButton->status;
		if(ptButton->status)//如果状态是1的话，颜色就变为绿色
		dwColor = BUTTON_PRESSED_COLOR;
	}
	else if(ptInputEvent->iType == INPUT_TYPE_NET)
	{
		/* 2. 对于网络类事件*/
		strButton = ptButton->name;
		//根据传进来的字符串改变颜色：wifi ok，wifi err, burn 70
		sscanf(ptInputEvent->str,"%s %s",name,status);
		if(strcmp(status,"ok") == 0)
			dwColor = BUTTON_PRESSED_COLOR;
		else if(strcmp(status,"err") == 0)
			dwColor = BUTTON_DEFAULT_COLOR;
		else if(status[0]>='0' && status[0]<='9')//如果第0项是数字的话，就把他设置为蓝色
		{
			dwColor = BUTTON_PERCENT_COLOR;
			strButton = status;
		}
		else
			return -1;
	}
	else
	{
		return -1;
	}
	/*绘制颜色*/
	DrawRegion(&ptButton->tRegion,dwColor);
	/*居中写文字*/
	DrawTextInRegionCentral(strButton, &ptButton->tRegion, BUTTON_TEXT_COLOR);
	/*刷新*/
	FlushDisplayRegion(&ptButton->tRegion, ptDispBuff);//将区域参数1刷新到参数2
	return 0;
}


//根据配置文件结果，即根据数组g_tItemCfgs[ITEMCFG_MAX_NUM]生成一个又一个的按钮
static void GenerateButtons(void)
{
	int width ,height;
	int n_per_line;//每行里面有多少个按钮
	int n;//表示有多少个按钮
	int row,rows;//先屏幕上显示，会有多少行
	int col;
	PDispBuff pDispBuff;
	int xres,yres;
	int start_x, start_y;
	PButton pButton;
	int i = 0;
	int pre_start_x,pre_start_y;
	/*1.算出单个按钮的width、hight*/
	g_tButtonCnt = GetItemCfgCount();//从配置文件得到有多少个按钮
	n = g_tButtonCnt;
	//获得分辨率
	pDispBuff = GetDisplayBuffer();//就可以从结构体pDispBuff里面得到x，y的分辨率
	xres = pDispBuff->iXres;
	yres = pDispBuff->iYres;
	width = sqrt(1.0 / 0.618 * xres * yres / n);//为了保证浮点运算，这样就算出了理想的宽度
	//担心这个宽度会导致越界，这个宽度还要减小点
	//先算出每一行显示多少个按钮
	n_per_line = xres / width + 1;//加1是为了让宽度更小
	width = xres / n_per_line;//这样的话，宽度将比理想宽度还要小
	height = 0.618 * width;

	/*2.居中显示：计算每个按钮的region*/
	//需要先算出第一个按钮左上角的位置
	start_x = (xres - width * n_per_line) / 2;//第一个按钮的起始x坐标
	rows 	= n / n_per_line;//如果算出来的结果带有小数点的话怎么办
	if(rows * n_per_line < n)//如果小于n，则表明有小数出现。
		rows++;
	start_y = (yres-rows * height) / 2;//第一个按钮的起始y坐标
	//然后就能计算每一个按钮的区域了
	for(row = 0; (row < rows) && (i<n); row++)
	{
		//处理每一行
		pre_start_y = start_y + row * height;
		pre_start_x = start_x - width;
		for(col = 0; (col < n_per_line) && (i<n); col++)
		{
			pButton = &g_tButtons[i];
			pButton->tRegion.iLeftUpX = pre_start_x + width;
			pButton->tRegion.iLeftUpY = pre_start_y;//同一行里面y坐标保持不变
			pButton->tRegion.iWidth   = width - X_GAP;//使得按钮之间保持间隔
			pButton->tRegion.iHeigh   = height - Y_GAP;
			pre_start_x = pButton->tRegion.iLeftUpX;//每次都要更新下pre

	/*3.初始化按钮InitButton*/
			InitButton(pButton,GetItemCfgByIndex(i)->name, NULL,NULL,MainPageOnPressed);
			i++;
			
		}
	}
	
	/*4.显示，调用OnDraw*/
	for(i=0;i<n;i++)
		g_tButtons[i].OnDraw(&g_tButtons[i],pDispBuff);
}

static int isTouchPonitInRegion(int iX,int iY, PRegion ptRegion)
{
	if(iX < ptRegion->iLeftUpX || iX >= ptRegion->iLeftUpX + ptRegion->iWidth)
		return 0;//表示不在这个区域里面
	if(iY < ptRegion->iLeftUpY || iY >= ptRegion->iLeftUpY + ptRegion->iHeigh)
		return 0;//表示不在这个区域里面
		
	return 1;
}

static PButton GetButtonByName(char *name)
{
	int i;

	for(i = 0; i< g_tButtonCnt; i++)
	{
		if(strcmp(name,g_tButtons[i].name) == 0)
			return &g_tButtons[i];
	}
	return NULL;
}


static PButton GetButtonByInputEvent(PInputEvent ptInputEvent)
{
	int i;
	char name[100];
	if(ptInputEvent->iType == INPUT_TYPE_TOUCH)//如果是触摸屏的话，则根据需要找到它的按钮
	{
		for(i = 0; i< g_tButtonCnt; i++)
		{
			if(isTouchPonitInRegion(ptInputEvent->ix,ptInputEvent->iy,&g_tButtons[i].tRegion))
				return &g_tButtons[i];
		}
	}
	else if(ptInputEvent->iType == INPUT_TYPE_NET)
	{
	//要先得到名字,从这个输入事件里面，把这个名字提取出来
		sscanf(ptInputEvent->str,"%s",name);
	//然后根据名字找到按钮
		return GetButtonByName(name);

	}
	else
	{
		return NULL;
	}
	return NULL;

}



static int MainPageRun(void *pParams)
{
	int error;
	InputEvent tInputEvent;//得到的输入事件，保存在这个结构体里面
	PButton ptButton;
	PDispBuff ptDispBuff;
	ptDispBuff = GetDisplayBuffer();
	/*1.读取配置文件*/
	error = ParseConfigFile();
	if(error)
	{
		return -1;
	}
	/*2.根据配置文件，生成各种按钮、界面*/
	GenerateButtons();

	while(1)
	{
		/*3.读取输入事件：比如有没有触摸屏数据或者网络数据*/
		error = GetInputEvent(&tInputEvent);
		if(error)
			continue;//如果有问题的话，就重新处理，反正不会退出

		/*4.根据输入事件，找到按钮*/
		ptButton = GetButtonByInputEvent(&tInputEvent);
		if(!ptButton)
			continue;//如果为空的话，就继续读取输入事件；

		/*5.调用按钮里面的OnPressed输入函数*/
		ptButton->OnPressed(ptButton, ptDispBuff, &tInputEvent);
		//使用上述函数的前提是，要构建对应按钮功能的OnPressed函数
		
	}
	return 0;
}

static PageAction g_tMainPage ={
	.name		= "main",//名字等于"main"
	.Run		= MainPageRun,
};

void MainPageregister(void)
{
	PageRegister(&g_tMainPage);//把自己构造的结构体注册到上层的页面管理器
}



