
//将以前写的show_ascii.c文件全部粘贴到这个文件中
#include <sys/mman.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <linux/fb.h>
#include <fcntl.h>
#include <stdio.h>
#include <string.h>
#include <sys/ioctl.h>
#include <stdlib.h>

#include "disp_manager.h"
#include "font_manager.h"
#include "input_manager.h"
#include "font_manager.h"
#include "page_manager.h"
int main(int argc, char **argv)
{
	int error;

	if(argc != 2)
	{
		printf("Usage: %s <font_file> \n",argv[0]);//font_file保存在argv[1]里面
		return -1;
	}
	
	//根据流程图，将各个模块初始化完成
	/*1.初始化显示系统*/
	//初始化显示事件
	DisplayInit();
	//选择默认的显示设备
	SelectDefaultDisplay("fb");
	//初始化默认的显示设备
	InitDefaultDisplay();

	/*2.初始化输入系统*/
	InputInit();
	InputDeviceInit();

	/*3.初始化文字系统*/
	//字体初始化，需要传入字库
	FontsRegister();

	//设置文件字库和初始化
	error = SelectAndInitFont("freetype",argv[1]);//参数1是选择某一个字库操作，参数2是字体文件，来源于输入参数
	if(error)
	{
		printf("SelectAndInitFont err\n");//font_file保存在argv[1]里面
		return -1;
	}

	/*4.初始化页面系统*/
	//ui系统不需要初始化，我们直接得到某个按钮就可以了
	PagesRegister();//注册进去

	//运行业务系统的主页面
	Page("main")->Run(NULL);//然后调用Page（“main”）里面的Run函数


	
	return 0;	
}

//从上面的main函数来看，根本就不涉及到硬件的操作，都被封装好了











