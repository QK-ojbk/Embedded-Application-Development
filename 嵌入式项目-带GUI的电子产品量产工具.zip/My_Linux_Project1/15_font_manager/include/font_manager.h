//对于头文件，为了防止重复包含，应该定义一些宏
#ifndef __FONT_MANAGER_H
#define __FONT_MANAGER_H

#ifndef NULL
#define NULL (void *)0
#endif

//下面的结构体用于描述位图
typedef struct FontBitMap {
	int iLeftUpX;//左上x
	int iLeftUpY;//左上Y
	int iWidth;//宽度
	int iRows;//行数
	int iCurOriginX;//当前字符基点的x坐标
	int iCurOriginY;//当前字符基点的Y坐标
	int iNextOriginX;//下一个字符基点的x坐标
	int iNextOriginY;//下一个字符基点的Y坐标
	//对于freetype字符而言，下一个字符的基点的坐标是可以计算出来的
	unsigned char *pucBuffer;//位图
}FontBitMap,*PFontBitMap;

//给定一个字符，如何得到一个FontBitMap;那么就还需要抽象出一个字库的操作结构体
typedef struct FontOpr {
	char *name;//用于辨别是使用freetype还是其它的字库
	//对于字库要提供一些初始化函数
	int (*FontInit)(char *aFineName);//里面的形参就是“使用的某个字体文件”
	int (*SetFontSize)(int iFontSize);//用于设置字体的大小，传入的形参为字体大小
	//获得某个字符的点阵,形参1为获得的字符的编码值,形参2为将获得的值放入的地方，即放入一个结构体中
	int (*GetFontBitMap)(unsigned int dwCode,PFontBitMap ptFontBitMap);
	//我们想要这个程序支持多种字库文件，应该构成一个指针链表
	struct FontOpr ptNext;
}FontOpr,*PFontOpr;

void FontsRegister(void);
void RegisterFont(PFontOpr ptFontOpr);
int SelectAndInitFont(char *aFontOprName,char *aFontFileName);
int SetFontSize(int iFontSize);
int GetFontBitMap(unsigned int dwCode,PFontBitMap ptFontBitMap);




#endif





