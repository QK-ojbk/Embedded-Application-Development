#include <disp_manager.h>
#include <stdio.h>
#include <string.h>
//管理底层的LCD、WEB，用一个链表来管理他们
static PDispOpr g_DispDevs = NULL;//先定义几个全局变量
static PDispOpr g_DispDefault = NULL;
static DispBuff g_tDispBuff;
static int line_width;
static int pixel_width;
//需要提供通用的函数
//如果想要在一块内存上面，来绘制点，也就是像素，它时绘制图片等的基础；那么它应该在这个文件里面实现
//因为上层代码，会通过disp_manager.c文件来访问Framebuffer和Web这些底层文件；
//这些绘制像素的函数，应该与硬件是没有什么关系的
int PutPixel(int x, int y, unsigned int dwColor)//在是什么位置绘制什么颜色的像素
{
	//为了显示一个像素，首先对于上层代码而言秒首先要得到一块内存，
	//这块内存由我们调用底层文件Framebuffer里面的g_tFramebufferOpr结构体里面的FbGetBuffer函数得到
	//得到一块buffer后，可以在这块内存里面绘制像素
	//然而将这个FbGetBuffer()函数放在PutPixel里面是不大恰当的，
	//还得要再提供一个函数,在选择默认的输出设备后，还得要初始化
	//参考以前的E:\QRS\QRS-Git\01_all_series_quickstart\04_嵌入式Linux应用开发基础知识\source\09_show_chinese里面的put_pixel函数
	unsigned char *pen_8 = (unsigned char *)g_tDispBuff.buff+y*line_width+x*pixel_width;
	unsigned short *pen_16;	
	unsigned int *pen_32;	

	unsigned int red, green, blue;	

	pen_16 = (unsigned short *)pen_8;
	pen_32 = (unsigned int *)pen_8;

	switch (g_tDispBuff.iBpp)//每个像素占据多少位
	{
		case 8:
		{
			*pen_8 = dwColor;
			break;
		}
		case 16:
		{
			/* 565 */
			red   = (dwColor >> 16) & 0xff;
			green = (dwColor >> 8) & 0xff;
			blue  = (dwColor >> 0) & 0xff;
			dwColor = ((red >> 3) << 11) | ((green >> 2) << 5) | (blue >> 3);
			*pen_16 = dwColor;
			break;
		}
		case 32:
		{
			*pen_32 = dwColor;
			break;
		}
		default:
		{
			printf("can't surport %dbpp\n", g_tDispBuff.iBpp);
			return -1;
			break;
		}
	}
	return 0;
}


//我们需要把底层模块，也就是framebuffer\WEB浏览器实现的那些结构体放入链表
void RegisterDisplay(PDispOpr ptDispOpr)//用于下一层结构体的注册进入这个链表，以便于被使用
{
	ptDispOpr->ptNext = g_DispDevs;//指向链表头
	g_DispDevs = ptDispOpr;
}

//假设链表g_DispDevs里面有很多模块，对于要使用那个模块，应该还要构造一个选择函数
int SelectDefaultDisplay(char *name)
{
	//根据名字，在链表中找到那一项;需要从头遍历整个链表
	PDispOpr pTmp = g_DispDevs;
	while(pTmp)
	{
		if(strcmp(name,pTmp->name) == 0)
		{
			g_DispDefault = pTmp;//找到了
			return 0;
		}
		pTmp = pTmp->ptNext;//当前的这个不对，就去取出下一个
	}
	return -1;
}

int InitDefaultDisplay(void)
{
	int ret;
	//在选择好输出设备后，则g_DispDefault的值为对应设备的结构体函数，此处为g_tFramebufferOpr
	ret = g_DispDefault->DeviceInit();
	if(ret)
	{
		printf("DeviceInit err\n");
		return -1;
	}
	
	ret = g_DispDefault->GetBuffer(&g_tDispBuff);
	//上面的GetBuffer函数会返回一个buffer的地址，并且还会把那些参数都保存在里面
	if(ret)
	{
		printf("GetBuffer err\n");
		return -1;
	}

	line_width = g_tDispBuff.iXres*g_tDispBuff.iBpp/8;//每一行占据多少个字节,知道每一行有多少个像素，每个像素有多少个位，再除以8，就能知道这行占据多少个字节
	pixel_width = g_tDispBuff.iBpp/8;//每个像素得到宽度

	return 0;
}

//提供一个函数，把得到的结构体返回给上一级的代码
PDispBuff GetDisplayBuffer(void)
{
	return &g_tDispBuff;
}

//再提供一个函数，用于将绘制好的像素刷到硬件上面去
//实际上在底层函数里面，实现了类似的函数，我们应该在上层代码中调用这个底层的函数
int FlushDisplayRegion(PRegion ptRegion, PDispBuff ptDispBuff)//第二个参数用前面构建的结构体，这样信息更多，更灵活
{
	g_DispDefault->FlushRegion(ptRegion, ptDispBuff);
	return 0;
}


//当想要使用显示系统时，首先要调用DisplayInit，然后它会导致FramebufferInit被调用
//而FramebufferInit()函数会把底层函数里面的结构体g_tFramebufferOpr注册进入这个链表g_DispDevs里面
void DisplayInit(void)//用于调用底层提供的函数
{
	extern void FramebufferInit(void);

	FramebufferInit();
	//WebInit()
}

//概述
//现在还没有实现WebInit()，以后自己去实现；
//首先对于注册函数RegisterDisplay()而言，会把底层函数的结构体放入链表；
//如果链表里面有很多项，里面对于很多不同的显示方式，则需要调用SelectDefaultDisplay()函数来选择调用哪一项，即默认的输出设备；
//选择好之后，则需要调用InitDefaultDisplay()函数来初始化这个设备：包括初始化硬件，获得buffer，
//完成上述内容之后，就可以调用PutPixel()函数在上面绘制图片了
//绘制好图片后，还可以调用FlushDisplayRegion()函数，把绘制好的这块区域刷到硬件上去
//以前可以直接打开LCD设备，直接在上面显示；现在之所以搞得很复杂，为的就是让这个程序更加容易扩展
//对于disp_manager这一文件，与硬件层没有关系了，以后修改底层的代码。换一个硬件显示，只需要提供对应的结构体就可以了
//这就是程序分层的概念

void DrawFontBitMap(PFontBitMap ptFontBitMap,unsigned int dwColor)
{
	int	i, j, p, q;
	int x = ptFontBitMap->tregion.iLeftUpX;
	int y = ptFontBitMap->tregion.iLeftUpY;
	int	x_max = x + ptFontBitMap->tregion.iWidth;
	int	y_max = y + ptFontBitMap->tregion.iHeigh;
	int width = ptFontBitMap->tregion.iWidth;
	unsigned char *buffer = ptFontBitMap->pucBuffer;
	//printf("x = %d, y = %d\n", x, y);
	
	for ( j = y, q = 0; j < y_max; j++, q++ )
	{
		for ( i = x, p = 0; i < x_max; i++, p++ )
		{
			if ( i < 0		|| j < 0	   ||
				i >= g_tDispBuff.iXres || j >= g_tDispBuff.iYres )
			continue;//如果x,y的坐标超过了屏幕的分辨率，则不处理它
	
			//image[j][i] |= bitmap->buffer[q * bitmap->width + p];
			if(buffer[q * width + p])//在位图里面，如果这个值为1，则我们就绘制这个点;值若为0，则不管
				PutPixel(i, j, dwColor);
		}
	}

}





