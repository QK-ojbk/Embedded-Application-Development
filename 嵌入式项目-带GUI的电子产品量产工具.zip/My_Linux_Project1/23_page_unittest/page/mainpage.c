
#include "page_manager.h"
#include <stdio.h>
static void MainPageRun(void *pParams)
{
	printf("%s %s %d \n", __FILE__, __FUNCTION__, __LINE__);

}

static PageAction g_tMainPage ={
	.name		= "main",//名字等于"main"
	.Run		= MainPageRun,
};

void MainPageregister(void)
{
	PageRegister(&g_tMainPage);//把自己构造的结构体注册到上层的页面管理器
}



