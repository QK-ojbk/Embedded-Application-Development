//将以前写的show_ascii.c文件全部粘贴到这个文件中
#include <sys/mman.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <linux/fb.h>
#include <fcntl.h>
#include <stdio.h>
#include <string.h>
#include <sys/ioctl.h>
#include <stdlib.h>

#include "page_manager.h"

int main(int argc, char **argv)
{
	PagesRegister();//注册进去
	Page("main")->Run(NULL);//然后调用Page（“main”）里面的Run函数
	return 0;	
}

//从上面的main函数来看，根本就不涉及到硬件的操作，都被封装好了




