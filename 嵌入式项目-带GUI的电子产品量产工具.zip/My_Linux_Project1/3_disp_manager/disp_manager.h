//对于头文件，为了防止重复包含，应该定义一些宏
#ifndef __DISP_MANAGER_H
#define __DISP_MANAGER_H

//先定义一些结构体
typedef struct DispBuff{
	int iXres;
	int iYres;
	int iBpp;
	char *buff;
}DispBuff,*PDispBuff;
typedef struct Region {
	int iLeftUpX;
	int iLeftUpY;
	int iWidth;//宽度
	int iHeigh;//高度
}Region,*PRegion;//我们用左上角的x,y坐标，和右下角的x,y坐标来表示一个区域;结构体以后用Region表示，指针以后用PRegion表示

typedef struct DispOpr {
	char *name;//名字
	int DeviceInit(void);
	int DeviceExit(void);
	int GetBuffer(PDispBuff ptDisBuff);//提供一个GetBuffer()函数,返回一个int值来表示“成功或者失败”
	//以后上层代码调用这个GetBuffer函数的时候,除了得到这个buf的显存的地址之外，还可以得到分辨率和每个像素使用多少位来表示
	int FlushRegion(PRegion ptRegion, PDispBuff ptDispBuff);//刷新某个区域，这个区域用结构体来表示，前面定义；要刷新的区域就是Region,数据在buffer里面
	struct DispOpr *ptNext;//指向下一个节点的指针域
}DispOpr,*PDispOpr;

void RegisterDisplay(PDispOpr ptDispOpr);
int SelectDefaultDisplay(char *name);
int InitDefaultDisplay(void);
int PutPixel(int x, int y, unsigned int dwColor);


#endif





