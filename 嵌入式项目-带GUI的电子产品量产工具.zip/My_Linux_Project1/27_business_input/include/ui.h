
#ifndef __UI_H
#define __UI_H
#include "common.h"
#include "disp_manager.h"
#include "input_manager.h"

#define BUTTON_DEFAULT_COLOR 0xff0000//默认为红色
#define BUTTON_PRESSED_COLOR 0x00ff00//按下后为绿色
#define BUTTON_TEXT_COLOR 0x000000//按钮里面的颜色为黑色
#define BUTTON_PERCENT_COLOR 0x0000ff


struct Button;



//函数名太长，重定义下
typedef int (*ONDRAW_FUNC)(struct Button *ptButton, PDispBuff ptDispBuff);
typedef int (*ONPRESSED_FUNC)(struct Button *ptButton, PDispBuff ptDispBuff, PInputEvent ptInputEvent);

typedef struct Button {
	char *name;//按键对应的名字
	int status;//用来标记点击状态
	Region tRegion;
	//绘制出来：形参1是绘制这个按钮本身，形参2是在哪里绘制
	//int (*OnDraw)(struct Button *ptButton, PDispBuff ptDispBuff);
	ONDRAW_FUNC OnDraw;
	//按钮绘制出来，那么人点击要有反应
	ONPRESSED_FUNC OnPressed;
}Button,*PButton;

void InitButton(PButton ptButton, char *name, PRegion ptRegion, ONDRAW_FUNC OnDraw, ONPRESSED_FUNC OnPressed);






#endif

