
#include "page_manager.h"
#include <stdio.h>
static void MainPageRun(void *pParams)
{
	/*1.读取配置文件*/


	/*2.根据配置文件，生成各种按钮、界面*/

	while(1)
	{
		/*3.读取输入事件：比如有没有触摸屏数据或者网络数据*/

		/*4.根据输入事件，找到按钮*/

		/*5.调用按钮里面的OnPressed输入函数*/
	}
	
}

static PageAction g_tMainPage ={
	.name		= "main",//名字等于"main"
	.Run		= MainPageRun,
};

void MainPageregister(void)
{
	PageRegister(&g_tMainPage);//把自己构造的结构体注册到上层的页面管理器
}



